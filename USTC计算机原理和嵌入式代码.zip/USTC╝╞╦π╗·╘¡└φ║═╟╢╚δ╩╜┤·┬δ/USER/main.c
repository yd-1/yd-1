#include"init_Timer.h"
#include"init_pwm.h"
#include"delay.h"
static int pwm=0;
void TIM3_IRQHandler()
{
	//�жϱ�־λ
	if(SET==TIM_GetITStatus(TIM3, TIM_IT_Update))
	{
		PGout(11)^=1;
	
	
		//��ձ�־λ
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	}
//	PGout(11)^=1;
//	//��ձ�־λ
//	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
}
int main(void)
{
	TIM3_init();
	
	NVIC_PriorityGroupConfig(2);
	PWM_init();
	delay_ms(168);
	while(1)
	{
		for(pwm=99;pwm>=0;pwm--)
		{
			TIM_SetCompare3(TIM2,pwm);
			delay_ms(20);
		}
		for(pwm=0;pwm<=99;pwm++)
		{
			TIM_SetCompare3(TIM2,pwm);
			delay_ms(20);
		}
		
	}
	
	
}

